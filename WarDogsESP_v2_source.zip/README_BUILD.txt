# WarDogs ESP v2 - SOURCE ARCHIVE (new offsets 2026-11-25) + build & run guide

Offsets compiled into wd_esp_full.c and offsets.txt:
  GNames   = 0xD14DD40   GObjects = 0xD220560
  GWorld   = 0xD3ACD08   GEngine  = 0xD3AFFC0
  VitalityState = 0x814  Bleedout byte at pawn+0x830 (= 0x814 + 0x1C), stance +0x831
All memory reads go through the kdmapper-mapped kernel driver (IOCTL backend);
the exe never uses ReadProcessMemory.

## What is inside this archive
  CoreWD_package/2_src_cheat/   overlay source (wd_esp_full.c, chams/, gpu.*, menu_webview.cpp, menu.html, build_cheat.bat)
  CoreWD_package/3_src_driver/  driver.c + build_driver.bat
  CoreWD_package/4_src_mapper/  kd2_src project files for the matching mapper fork
  kdmapper-master/              full kdmapper sources (mapper)
  offsets.txt / RUN_STEPS.md / HOW_TO_UPDATE.md

NOT included (fetch locally):
  1. WebView2 SDK headers+loader -> NuGet package "Microsoft.Web.WebView2"
  2. prebuilt binaries (.exe/.dll/.sys) -> rebuild them with the scripts below

## Step-by-step on Windows 11 x64
Prereqs: Visual Studio 2022 with "Desktop development with C++", Windows 11 SDK (10.0.26100).

1. Extract this archive to C:\wd\
2. Get the WebView2 SDK:
     cd C:\wd\CoreWD_package\2_src_cheat
     nuget install Microsoft.Web.WebView2 -OutputDirectory wv2pkg
   then create folder WebView2SDK and copy contents of
     wv2pkg\Microsoft.Web.WebView2.<version>\build\native\  ->  WebView2SDK\
   (you need include\WebView2.h + x64\WebView2Loader.dll + .lib)
   Alternative: download the nupkg from https://www.nuget.org/packages/Microsoft.Web.WebView2
   and extract it with 7-Zip.
3. Build the overlay:
     build_cheat.bat
   -> WarDogsESP_v2.exe (+ WebView2Loader.dll copied next to it; menu.html must stay beside the exe)
   If vcvars64.bat is not found, edit the VS path at the top of build_cheat.bat.
4. Build the driver (needs WDK headers from the Windows SDK):
     cd ..\3_src_driver
     build_driver.bat
   -> driver.sys
5. Build the mapper:
     open kdmapper-master\kdmapper.sln in VS2022, build Release x64 -> kdmapper.exe
6. Disable Secure Boot: reboot -> BIOS/UEFI -> Security -> Secure Boot -> Disabled (required for mapping an unsigned driver).
7. Deploy one run folder, e.g. C:\wd\run\ containing:
     WarDogsESP_v2.exe   WebView2Loader.dll   menu.html   driver.sys   kdmapper.exe
8. Start War Dogs, get into a match.
9. Elevated CMD (Run as administrator):
     cd C:\wd\run
     kdmapper.exe driver.sys      (should print the mapped base address)
10. Still elevated: start WarDogsESP_v2.exe
    - If it says "Kernel backend unavailable - map the driver", step 9 failed.
    - Overlay draws boxes/skeleton/names/health/weapon; F1 opens the settings menu.

## Quick sanity checks
- kdmapper prints "Driver mapped successfully @ 0x..." before running the exe.
- The exe resolves the game module base via IOCTL_BASE (driver), not toolhelp/RPM.
- Offsets live in wd_esp_full.c lines ~65-174 and ~1516; update them there after each game patch (see HOW_TO_UPDATE.md).
